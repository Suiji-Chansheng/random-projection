Other.classifier <-
    function(x #n by p trining data matrix
           , grouping #n vector of the classes of the trining samples
           , xTest  #n.test by p test data matrix
           , CV = FALSE #performs leave-one-out cross-validation if CV is TRUE 
           ,...)
        {
		
		
		
		  if(CV==TRUE)
            otherfier<-randomForest(x , y=factor(grouping),ntree=1000)
          if(CV==FALSE)
          {
            RandForest<-randomForest(x,y=factor(grouping),ntree=1000)
  
            otherfier<-predict(RandForest, newdata = xTest)
           }     
    
         return(otherfier)
   }
